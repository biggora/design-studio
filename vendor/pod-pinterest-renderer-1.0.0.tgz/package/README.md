# Pinterest renderer v1

Portable SVG + Sharp renderer. Text is shaped with fontkit and embedded as paths;
Inter 900 and Noto Serif 700 WOFF files and their OFL licenses ship in `fonts/`.
No system fonts, browser, network, database, or AI service is involved.

The immutable assignment freezes template, colours, title, text layout, branding,
source URLs, checksums and crops. `renderPin` verifies all source checksums and
returns a 1000×1500 JPEG ≤1 MiB. Keep v1 available when adding a future renderer.

Build: `pnpm --filter @pod/pinterest-renderer build`.
The workspace root `pnpm install` also builds this package for a clean checkout.
Pack: `npm pack --pack-destination <design-studio>/vendor` from this directory,
then install the resulting archive in design-studio. Commit the archive and both
lockfiles. Source changes must be packed and tested in both consumers together;
after shipping v1, use a new package version for changes and preserve v1 rendering.

Local reference gallery, using the previously downloaded source snapshots:

```powershell
pnpm exec tsx apps/cli/scripts/pinterest-reference-gallery.ts <samples.json> <output-directory>
```

The gallery runs the real preview command; any attempted API write throws.
