# OG renderer v1

1200 x 630 JPEG, at most 1 MiB. Four approved layouts, seven palettes. Network and persistence belong to the caller. Render only frozen assignments; preserve v1 for saved images. Bundled fonts have OFL licenses in fonts/.
